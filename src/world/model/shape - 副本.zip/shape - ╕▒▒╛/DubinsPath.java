/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package world.model.shape;

/**
 *
 * @author boluo
 */
public class DubinsPath {

    public static enum Segment {

        LEFT, STRAIGHT, RIGHT
    }
    /**
     * Path segment types
     */
    Segment[] type;
    /**
     * Path segment lengths
     */
    double[] lengths = new double[3];
    /**
     * Whether the path should be followed "in reverse"
     */
    boolean reverse = false;

    DubinsPath() {
        this(new DubinsPath.Segment[]{DubinsPath.Segment.LEFT, DubinsPath.Segment.STRAIGHT, DubinsPath.Segment.LEFT}, 0, Double.MAX_VALUE, 0);
    }

    DubinsPath(Segment[] type, double t, double p, double q) {
        assert type.length == 3;
        this.type = type;
        lengths[0] = t;
        lengths[1] = p;
        lengths[2] = q;
        assert (t >= 0.);
        assert (p >= 0.);
        assert (q >= 0.);
    }

    public double length() {
        return lengths[0] + lengths[1] + lengths[2];
    }

    public double[] getSegmentLengths() {
        return lengths;
    }

    public Segment[] getSegmentTypes() {
        return type;
    }
}
