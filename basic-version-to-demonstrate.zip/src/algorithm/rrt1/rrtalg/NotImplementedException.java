package algorithm.rrt1.rrtalg;

public class NotImplementedException extends RuntimeException {
	
	public NotImplementedException() {
		super();
	}
	
	public NotImplementedException(String message) {
		super(message);
	}
	
}
