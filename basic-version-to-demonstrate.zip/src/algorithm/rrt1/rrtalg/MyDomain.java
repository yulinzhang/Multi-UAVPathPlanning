package algorithm.rrt1.rrtalg;

import algorithm.RRT.RRTNode;
import algorithm.rrt1.domain.Domain;
import algorithm.rrt1.util.Extension;
import algorithm.rrt1.util.ExtensionEstimate;
import algorithm.rrt1.util.Vertex;
import config.StaticInitConfig;
import java.util.ArrayList;
import java.util.Random;
import util.ConflictCheckUtil;
import util.DistanceUtil;
import util.VectorUtil;
import world.World;
import world.model.Obstacle;
import world.model.shape.DubinsCurve;
import world.model.shape.Point;
import world.model.shape.Trajectory;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author boluo
 */
public class MyDomain implements Domain<Point, Edge> {

    private ArrayList<Obstacle> obstacles;
    protected Point goal;
    protected double tryGoalRatio;
    protected Random random;
    protected float speed = 10;
    protected double max_angle = Math.PI / 12;
    private float adaptive_target_reached_radius_check = 5;
    private Point initialState;

    /**
     *
     * @param obstacles
     * @param goal
     * @param tryGoalRatio
     */
    public MyDomain(ArrayList<Obstacle> obstacles, Point initialState, Point goal, double tryGoalRatio) {
        this.obstacles = obstacles;
        this.goal = goal;
        this.tryGoalRatio = tryGoalRatio;
        this.random = new Random(System.currentTimeMillis());
        this.initialState = initialState;
        adaptive_target_reached_radius_check = Math.min(adaptive_target_reached_radius_check, DistanceUtil.distanceBetween(initialState.toFloatArray(), goal.toFloatArray()) / 2);
    }

    @Override
    public Point sampleState() {
        if (random.nextDouble() <= tryGoalRatio) {
            return goal;
        }
        float[] random_goal_coordinate = new float[2];
        random_goal_coordinate[0] = (float) (Math.random() * World.bound_width);
        random_goal_coordinate[1] = (float) (Math.random() * World.bound_height);
        boolean collisioned = true;
        while (collisioned) {
            random_goal_coordinate[0] = (float) (Math.random() * World.bound_width);
            random_goal_coordinate[1] = (float) (Math.random() * World.bound_height);
            if (!ConflictCheckUtil.checkPointInObstacles(obstacles, random_goal_coordinate[0], random_goal_coordinate[1])) {
                collisioned = false;
            }
        }
        Point point = new Point(random_goal_coordinate[0], random_goal_coordinate[1], 0);
        return point;
    }

    @Override
    public Extension<Point, Edge> extendTo(Vertex<Point, Edge> from_vertext, Point to) {
//        Point from = from_vertext.getState();
//        boolean conflict_result = ConflictCheckUtil.checkLineInObstacles(obstacles, from.toFloatArray(), to.toFloatArray());
//        if (conflict_result) {
//            return null;
//        }
//
//        Edge edge = new Edge(from, to);
//        boolean exact = false;
//        if (DistanceUtil.distanceBetween(to.toFloatArray(), to.toFloatArray()) < 2) {
//            exact = true;
//        }
//        Extension<Point, Edge> extension = new Extension<Point, Edge>(from, to, edge, edge.getCost(), exact);//S source, S target, E edge, double cost, boolean exact
//        return extension;
        return extendToWithOneStep(from_vertext,to);
    }

    public Extension<Point, Edge> extendToWithDynamics(Vertex<Point, Edge> from_vertext, Point to) {
        Point from = from_vertext.getState();
        double from_angle = 0;
        Vertex<Point, Edge> parent_of_from = from_vertext.getParent();
        if (parent_of_from != null) {
            Point parent_of_from_point = parent_of_from.getState();
            from_angle = VectorUtil.getAngleOfVectorRelativeToXCoordinate(from.getX() - parent_of_from_point.getX(), from.getY() - parent_of_from_point.getY());
        }
        double toward_goal_angle = VectorUtil.getAngleOfVectorRelativeToXCoordinate(to.getX()-from.getX(), to.getY()-from.getY());
        double delta_angle = VectorUtil.getBetweenAngle(toward_goal_angle, from_angle);

        if (delta_angle > max_angle) {
            return null;
        }
        
        boolean conflict_result = ConflictCheckUtil.checkLineInObstacles(obstacles, from.toFloatArray(), to.toFloatArray());
        if (conflict_result) {
            return null;
        }

        Edge edge = new Edge(from, to);
        boolean exact = false;
        if (DistanceUtil.distanceBetween(to.toFloatArray(), to.toFloatArray()) < 2) {
            exact = true;
        }
        Extension<Point, Edge> extension = new Extension<Point, Edge>(from, to, edge, edge.getCost(), exact);//S source, S target, E edge, double cost, boolean exact
        return extension;
    }

    public Extension<Point, Edge> extendToWithoutDynamics(Vertex<Point, Edge> from_vertext, Point to) {
        Point from = from_vertext.getState();
        boolean conflict_result = ConflictCheckUtil.checkLineInObstacles(obstacles, from.toFloatArray(), to.toFloatArray());
        if (conflict_result) {
            return null;
        }

        Edge edge = new Edge(from, to);
        boolean exact = false;
        if (DistanceUtil.distanceBetween(to.toFloatArray(), to.toFloatArray()) < 2) {
            exact = true;
        }
        Extension<Point, Edge> extension = new Extension<Point, Edge>(from, to, edge, edge.getCost(), exact);//S source, S target, E edge, double cost, boolean exact
        return extension;
    }

    public Extension<Point, Edge> extendToWithOneStep(Vertex<Point, Edge> from_vertext, Point to) {
        Point from = from_vertext.getState();
        Point next_point = extendTowardGoalWithDynamics(from.toFloatArray(), from.getYaw(), to.toFloatArray(), Float.MAX_VALUE, this.max_angle);
        if (next_point == null) {
            return null;
        }
        Edge edge = new Edge(from, next_point);
        boolean exact = false;
        if (DistanceUtil.distanceBetween(to.toFloatArray(), next_point.toFloatArray()) < 1) {
            exact = true;
        }
        Extension<Point, Edge> extension = new Extension<Point, Edge>(from, next_point, edge, edge.getCost(), exact);//S source, S target, E edge, double cost, boolean exact
        return extension;
    }

    /**
     * extend toward goal location
     *
     * @param nearest_node
     * @param random_goal_coordinate
     * @param max_length
     * @param max_angle
     * @return
     */
    protected Point extendTowardGoalWithDynamics(float[] nearest_coordinate, double current_angle, float[] random_goal_coordinate, float max_length, double max_angle) {

        double toward_goal_angle = VectorUtil.getAngleOfVectorRelativeToXCoordinate(random_goal_coordinate[0] - nearest_coordinate[0], random_goal_coordinate[1] - nearest_coordinate[1]);
        double delta_angle = VectorUtil.getBetweenAngle(toward_goal_angle, current_angle);
        float[] new_node_coord = new float[2];
        float len = max_length;
        if (delta_angle > max_angle) {
            double temp_goal_angle1 = VectorUtil.getNormalAngle(current_angle - max_angle);
            double delta_angle_1 = VectorUtil.getBetweenAngle(toward_goal_angle, temp_goal_angle1);

            double temp_goal_angle2 = VectorUtil.getNormalAngle(current_angle + max_angle);
            double delta_angle_2 = VectorUtil.getBetweenAngle(toward_goal_angle, temp_goal_angle2);

            if (delta_angle_1 < delta_angle_2) {
                toward_goal_angle = temp_goal_angle1;
            } else {
                toward_goal_angle = temp_goal_angle2;
            }
        } else {
            len = Math.min(DistanceUtil.distanceBetween(nearest_coordinate, random_goal_coordinate), max_length);
        }
        boolean conflicted = true;
        while (conflicted) {
            new_node_coord[0] = nearest_coordinate[0] + (float) (Math.cos(toward_goal_angle) * len);
            new_node_coord[1] = nearest_coordinate[1] + (float) (Math.sin(toward_goal_angle) * len);
            conflicted = ConflictCheckUtil.checkPointInObstacles(obstacles, new_node_coord[0], new_node_coord[1]);
            len = len / 2;
            if (len < 2 && conflicted) {
                break;
            }
        }
        if (conflicted) {
            return null;
        }
        Point new_node = new Point(new_node_coord[0], new_node_coord[1], toward_goal_angle);
        return new_node;
    }

    @Override
    public ExtensionEstimate estimateExtension(Point from, Point to) {
        return new ExtensionEstimate(DistanceUtil.distanceBetween(from.toFloatArray(), to.toFloatArray()), true);
    }

    @Override
    /**
     * estimate cost to go to target
     *
     */
    public double estimateCostToGo(Point s) {
        return DistanceUtil.distanceBetween(s.toFloatArray(), goal.toFloatArray());
    }

    @Override
    public double distance(Point s1, Point s2) {
        return DistanceUtil.distanceBetween(s1.toFloatArray(), s2.toFloatArray());
    }

    @Override
    public double nDimensions() {
        return 2;
    }

    @Override
    public boolean isInTargetRegion(Point s) {

        if (DistanceUtil.distanceBetween(s.toFloatArray(), goal.toFloatArray()) < 1) {
            if (adaptive_target_reached_radius_check > 2) {
                adaptive_target_reached_radius_check = adaptive_target_reached_radius_check / 2;
            }
            return true;
        } else {
            return false;
        }
    }

}
